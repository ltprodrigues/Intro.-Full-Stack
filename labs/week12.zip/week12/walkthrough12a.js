//declare vars
let a = 10
console.log("Number: ", a);
//const value
const b = "hello"
console.log("String: ", b);
//create a function => add
function add(a, b){
    return a + b
}

// calling
console.log("Add: ", add(5,10));