let b = "Hello"
console.log("This is file B: ", b);