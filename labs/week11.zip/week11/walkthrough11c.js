let c = "GBC";

console.log("This is file C: ", c);
export {c}