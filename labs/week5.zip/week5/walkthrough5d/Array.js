//1 Describe the file name
describe('Array', function () {
    //2 Describe the function name (.functionName)
describe('.pop', function () {
//3 Write the instructions
    it("remove the item", function () {
        var arr = [1, 2, 3];
    })
 });
    describe('.add', function () {
//3 Write the instructions
        it("remove the item", function () {

        })
    });



});